#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
#dbresult = hottopicdb.find().limit(number)
dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2014-05-16 00:00:00','$lt':'2014-05-27 23:59:59'}})

number =dbresult.count()
print number

sets = set()
topicdic = {
		}
timelist = []
countnumber =0
countnumbers =0
mingzi = "霍建华"

"""
#第一遍
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			if not topicdic.has_key(name['name']):
				topicdic[name['name']] = [-1]*number
	#print topic['crawl_time']
	#timelist[countnumbers]=topic['crawl_time']
	timelist.append(topic['crawl_time'])
"""

topicdic[mingzi] = [0]*number
for topic in dbresult:
	timelist.append(topic['crawl_time'])

#第二遍遍历
dbresult.rewind()
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			if(name['name'].encode("utf-8")==mingzi):
				templist = topicdic[name['name'].encode('utf-8')]
				templist[countnumber]= name['amount']
	countnumber = countnumber+1


"""
#按照name进行聚合
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			if not topicdic.has_key(name['name']):
				topicdic[name['name']] = [[name['amount'],topic['crawl_time']]]
			else:
				templist  = topicdic[name['name']]
				templist.append([name['amount'],topic['crawl_time']])
			#print set

	topicdic[topic['crawl_time']] = templist
"""
#将内容写进文件里面
#name name name 格式
outFile = open("../data/"+mingzi+".txt","w")
outFile.write("time")
outFile.write(",")
outFile.write("Query")
#outFile.write(",")
#outFile.write("Tweet")
outFile.write("\n")

for n in range(1,number,1):
	#添加行号
	#outFile.write(str(n))
#	if(templist[n-1]!=0):
	outFile.write(timelist[n-1])
	outFile.write(",")
	templist = topicdic[mingzi]
	outFile.write(str(templist[n-1]))
#	outFile.write(",")
	outFile.write("\n")

"""
#name amount time,格式
outFile = open("calword.txt","w")
for word in topicdic.keys():
	outFile.write(word.encode('utf8'))
	outFile.write("\n")
	for element in topicdic[word]:
		sep=','
		outFile.write(sep.join(element))
		outFile.write("\n")

	
	for temp in finalresult:
		print "hello"
		outFile.write("hello")
		for kk,vv in temp['trends'].items():
			for names in vv:
				if names['name']== word:
					outFile.write(names['amount'])
					outFile.write(" ")
					outFile.write(temp['crawl_time'])
					outFile.write("\n")
				else:
					outFile.write("no words")
"""

outFile.close()



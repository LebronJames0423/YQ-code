#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2014-05-05 00:00:00','$lt':'2014-06-04 23:59:59'}})

number =dbresult.count()
print number


sets = set()
topicdic = {}
timelist = []
countnumber =0
countnumbers =0
tempwordcount =0
timedic = {}

#第一遍
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			if not topicdic.has_key(name['name']):
				timedic={}
				timedic[topic['crawl_time']]=int(name['amount'])
				topicdic[name['name']] = timedic
			else:
				temp=topicdic[name['name']]
				temp[topic['crawl_time']]=int(name['amount'])
				topicdic[name['name']]=temp

outFile = open("../data/words20140604.txt","w")
#topiclist = topicdic.items()
#topiclist.sort(cmp=lambda x,y:cmp(x[1]['crawl_time'],y[1]['crawl_time']),reverse=True)
print len(topicdic)

for t in topicdic.keys():
	tonumber = 0
	for n in topicdic[t].keys():
		tonumber += topicdic[t][n] 
	num = tonumber/len(topicdic[t])
	topicdic[t]=num
topiclist = topicdic.items()
topiclist.sort(cmp=lambda x,y:cmp(x[1],y[1]),reverse=True)

for word in topiclist:
	outFile.write(word[0].encode('utf8'))
	outFile.write(",")
	outFile.write(str(word[1]))
	outFile.write('\n')


"""
for word in topicdic.keys():
	outFile.write(word.encode('utf8'))
	outFile.write(",")
	for words in topicdic[word].keys():
		outFile.write(words)
		outFile.write(",")
		outFile.write(str(topicdic[word][words]))
		outFile.write("\n")

"""
"""
for word in topicdic.keys():
	outFile.write(word.encode('utf8'))
	outFile.write(",")
	outFile.write(str(topicdic[word]))
	outFile.write(",")
	outFile.write("\n")
"""

outFile.close()

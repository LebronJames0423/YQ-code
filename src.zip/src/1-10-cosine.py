#!/usr/bin/env python
#encoding: utf8
import math


def cosine(vectorA,vectorB):
	length = len(vectorA)
	sum = 0
	sqrtA = 0
	sqrtB = 0
	for i in range(length):
		sum += vectorA[i]*vectorB[i]
		sqrtA += vectorA[i]*vectorA[i]
		sqrtB += vectorB[i]*vectorB[i]
	result = sum/(math.sqrt(sqrtA)*math.sqrt(sqrtB))
	return result
	

if __name__ == '__main__':
	vectorA=[1,2,2,1,1,1,0]
	vectorB=[1,2,2,1,1,2,1]
	result = cosine(vectorA,vectorB)
	print result


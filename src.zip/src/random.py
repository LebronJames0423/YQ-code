#coding=utf8
import math
import random

filename='Tweet.txt'
writeFilename = 'EmergingHours.txt'
filecount=0
res_num = 0

def LoadFile():
	zyyfile = open("../data/"+filename,"r")
	slice = random.sample(zyyfile,res_num)

	for line in slice.readlines():
		ti = line.strip('\n').split(',',3)
		tweetcontent.append(ti)

	zyyfile.close()

def WriteFile():
	zy = open("../data/"+writeFilename+".txt","w")
	for jj in tweetcontent:
		zy.write(str(jj).encode('utf8'))
		zy.write(';')
		zy.write("\n")
	zy.close()

def main():
	LoadFile()
	WriteFile()

if __name__=="__main__":
	main()

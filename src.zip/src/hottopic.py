from weibo import APIClient
import urllib
import httplib
from MongoDb import MongoDb
import time


APP_KEY = '' #申请开发者的key
APP_SECRET = '' #申请开发者的
CALLBACK_URL = 'http://219.223.220.21'
CALLBACK_URL = 'http://apps.weibo.com/hellowangsibo'
ACCOUNT = ''# 申请时your email address
PASSWORD = ''#your pw

config = {
	'hottopicdb':{
		'host':'219.223.215.190',
		'port':27017,
		'db':'weibo_TrendsV1',
		'collection':'hottopic'
		}
	}



#for getting the authorize url
client = APIClient(app_key=APP_KEY, app_secret=APP_SECRET, redirect_uri=CALLBACK_URL)
url = client.get_authorize_url()
print url

#for getting the code contained in the callback url
def get_code():
	conn = httplib.HTTPSConnection('api.weibo.com')
	postdata = urllib.urlencode({
		'client_id':APP_KEY,
		'response_type':'code',
		'redirect_uri':CALLBACK_URL,
		'action':'submit',
		'userId':ACCOUNT,
		'passwd':PASSWORD,
		'isLoginSina':0,'from':'','regCallback':'','state':'','ticket':'','withOfficalFlag':0
	})

	conn.request('POST','/oauth2/authorize',postdata,{ 'Referer':url,'Content-Type': 'application/x-www-form-urlencoded' })
	res = conn.getresponse()
	"""
	print 'headers===========',res.getheaders()
	print 'msg===========',res.msg
	print 'status===========',res.status
	print 'reason===========',res.reason
	print 'version===========',res.version
	"""
	location = res.getheader('location')


	#print location

	code = location.split('=')[-1]
	conn.close()
	#print code
	return code


code = get_code()
r = client.request_access_token(code)
access_token = r.access_token # The token return by sina
expires_in = r.expires_in


#save the access token
client.set_access_token(access_token, expires_in)

#print client.get.statuses__user_timeline()
#print client.post.statuses__update(status='Python Sina microblog for OAuth 2.0 testing')


#print client.trends.daily.get()
result = client.trends.daily.get()
#result = client.trends.hourly.get()
#result = client.trends.weekly.get()
#print result['trends']

hottopicdb = MongoDb(config['hottopicdb'])

now = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
now = now.decode('utf8')
result['crawl_time'] = now
#1 by hour,2 by day
result['trends_by'] = 1
print result
"""
#hottopicdb.save(result)
dbresult = hottopicdb.loadItemsByCondition({},2)
#print dbresult['trends']
for item in dbresult:
	print item

for k,v in result['trends'].items():
	for topic in v:
		print k,topic['name'],topic['delta']
		#print k,topic['name'],topic['delta']
		#print topic
"""

#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
import time
import datetime
import math

config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2013-09-04 00:00:00','$lt':'2013-11-04 23:59:59'}})

dbresult_s = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2014-04-26 00:00:00','$lt':'2014-07-03 23:59:59'}})
number =dbresult.count()
print number

sets = set()
topicdic = {}
topicFre={}
timelist = []
countnumber =0
countnumbers =0
format = "%Y-%m-%d %H:%M:%S" 
#按照name进行聚合
for topic in dbresult:
	topictime = topic['crawl_time']
	for k,v in topic['trends'].items():
		for name in v:
			rname=name['name'].encode('utf8')
			if not topicdic.has_key(rname):
				topicdic[rname]=[[topictime,name['amount']]]
			else:
				topicdic[rname].append([topictime,name['amount']])

for topic in dbresult_s:
	topictime = topic['crawl_time']
	for k,v in topic['trends'].items():
		for name in v:
			rname=name['name'].encode('utf8')
			if not topicdic.has_key(rname):
				topicdic[rname]=[[topictime,name['amount']]]
			else:
				topicdic[rname].append([topictime,name['amount']])

def EmergingAvergeTimes(categ):
#cate 为1表示按照hours算平均，categ为2表示按照新算法取天数
	if categ == 1:
		for s in topicdic.keys():
			totalamount=0
			for n in topicdic[s]:
				totalamount+=int(n[1].encode('utf8'))
			num = len(topicdic[s])
			topic_ave_hour=round(totalamount/float(num),2)
			topicFre[s]=topic_ave_hour

	if categ ==2:
		resultday={}
		readfile=open('../data/Topic_Days.txt','r')
		for line in readfile.readlines():
			item = line.strip('\n').split(',')
			resultday[item[1]]=int(item[2])
		readfile.close()

		for s in topicdic.keys():
			totalamount=0
			for n in topicdic[s]:
				totalamount+=int(n[1].encode('utf8'))
			num=resultday[s]
			topic_ave_day=round(totalamount/float(num),2)
			if s =='华晨宇':
				print num
				print totalamount
			topicFre[s]=topic_ave_day

	wordlist = topicFre.items()
	wordlist.sort(cmp=lambda x,y:cmp(x[1],y[1]),reverse=True)
	#name amount time,格式
	if categ==2:
		outFile = open("../data/Topic_Avg_Day.txt","w")
	elif categ==1:
		outFile = open("../data/Topic_Avg_Hour.txt","w")

	outFile.write("#Rank")
	outFile.write(',')
	outFile.write("topic")
	outFile.write(",")
	outFile.write("Average")
	outFile.write("\n")
	num = 1
	for word in wordlist:
		outFile.write(str(num))
		outFile.write(",")
		outFile.write(word[0])
		outFile.write(",")
		outFile.write(str(word[1]))
		outFile.write("\n")
		num+=1
		
	outFile.close()

EmergingAvergeTimes(1)
EmergingAvergeTimes(2)

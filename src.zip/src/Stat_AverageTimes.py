#coding=utf8
import math
import Topic_eme_times

Amount = {}
AmountQ = 0
keylist =[]
categ =2 
if categ==1 :
	zyyfile = open("../data/Topic_Avg_Hour.txt","r")
elif categ==2:
	zyyfile = open("../data/Topic_Avg_Day.txt","r")


zyyfile.readline()
for line in zyyfile.readlines():
	ti = line.strip('\n').split(",")
	if not Amount.has_key(float(ti[2])):
		Amount[float(ti[2])]=[ti[1]]
	else:
		Amount[float(ti[2])].append(ti[1])
	AmountQ+=1


'''
zyyfile.readline()
for line in zyyfile.readlines():
	ti = line.split(",")
	sti = math.ceil(int(ti[1])/24.0)
	if not Amount.has_key(int(sti)):
		Amount[int(sti)]=int(ti[2])
	else:
		Amount[int(sti)]+=int(ti[2])
	AmountQ+=1
'''



if categ==1 :
	zy= open("../data/TopicAvgNumbersHour.txt","w")
elif categ==2:
	zy = open("../data/TopicAvgNumberDay.txt","w")


keylist = Amount.keys()
keylist.sort(reverse = True)
zy.write("rank")
zy.write(",")
zy.write("times")
zy.write(",")
zy.write("number")
zy.write("\n")
rank=1
for jj in keylist:
	zy.write(str(rank))
	zy.write(",")
	zy.write(str(jj))
	zy.write(",")
	zy.write(str(len(Amount[jj])))
	zy.write("\n")		
	rank+=1
print len(Amount)
zyyfile.close()
zy.close()


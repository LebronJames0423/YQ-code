#-!-encoding:utf-8-!-
import datetime
import time

weibofile = open('1-yes-seg-without-stop.out','r')
yesfile = open('1-yes-words-count.out','w')
tffile = open('1-yes-words-tf.out','w')


num = 0
result = { }
resultTF = { }
wordCount = 0
for l in weibofile:
	num+=1
	words = l.split()
	for w in words:
		wordCount += 1
		result[w] = result.get(w,0)+1
print "read ok"

for k,v in result.iteritems():
	outline = k+" "+str(v)+"\n"
	yesfile.write(outline)
	tf = float(v)/wordCount
	outline = k+" "+str(tf)+"\n"
	tffile.write(outline)
print "tf ok"


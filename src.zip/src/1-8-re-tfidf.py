#-!-encoding:utf-8-!-
import datetime
import time
import math


tffile = open('1-5yes-words-tf.out','r')
idffile = open('1-5yes-words-idf.out','r')
tfidffile = open('1-5yes-words-tfidf.out','w')


tf= { }
idf= { }
tfidf = { }
num=0

for l in tffile:
	num+=1
	l = l.strip()
	words = l.split(' ',1)
	if len(words)<2:
		print str(num)+":tf words len < 2"
	tf[words[0]] = float(words[1])
print "read tf ok"

num=0
for l in idffile:
	num+=1
	l = l.strip()
	words = l.split(' ',1)
	if len(words)<2:
		print str(num)+":idf words len < 2"
	idf[words[0]] = float(words[1])
print "read idf ok"


for k,v in tf.iteritems():
	if k in idf:
		tfidf[k] = v*idf[k]
	else:
		tfidf[k] = v*0
		print k+": not in idf"
print "tfidf ok"

result = [[v[1],v[0]] for v in tfidf.items()]
result.sort(reverse=True)
for v in result:
	outline = v[1]+" "+str(v[0])+"\n"
	tfidffile.write(outline)
print "sort ok"



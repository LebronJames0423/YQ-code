# -*- coding: utf-8 -*-
import decimal
#mysqldb
import MySQLdb

"""Connect"""
conn = MySQLdb.connect(host ="localhost",user="wangsibo",passwd="wangsibo",db="baidu_news",charset="utf8")
cursor  = conn.cursor()


"""Index"""
result = cursor.execute("select * from hotword")
'''
for i in cursor.fetchall():
	print i[2]
'''

Rfile = open("../data/words0616_23.txt","r")
Wfile = open("../data/BaiduWeiboSimWords.txt","w")

HotQuery = []
for lines in Rfile.readlines():
	lines = lines.decode('utf8')
	lines = lines.strip()
	line= lines.split(',')
	HotQuery.append(line[0])

temp_baidu = cursor.fetchall()

Result={}
for topic in HotQuery:
	topiclen = len(topic)

	for row in temp_baidu:
		count = 0
		#print type(topic)
		#baidu_hottopic = row[2].decode('utf8')
		baidu_hottopic = row[2]
		baidu_hottopiclen = len(row[2])
		for word in topic:
			#print word
			if word in baidu_hottopic:
				count+=1
		LenRes=decimal.Decimal(count * count)/(topiclen * baidu_hottopiclen)
		'''
		调试看是否正常统计数字
		if topic.encode('utf8') == "杨幂" and count>=1:
			print str(count)+","+ str(LenRes)
		'''
		if float(LenRes) >= 0.2 and float(count)/topiclen >=0.6:
			if topic not in Result.keys():
				Result[topic]=[baidu_hottopic]
			elif baidu_hottopic not in Result[topic]:
				Result[topic].append(baidu_hottopic)

		else:
			continue
for k in Result.keys():
	print k
	Wfile.write(k.encode('utf8')+': ')
	for btopic in Result[k]:
		Wfile.write(','+ btopic.encode('utf8'))
	Wfile.write('\n')

	
Rfile.close()
Wfile.close()


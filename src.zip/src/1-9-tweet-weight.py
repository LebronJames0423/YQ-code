#-!-encoding:utf-8-!-
import datetime
import time

originweibofile = open('1-5yes.out','r')
weibofile = open('1-5yes-seg-without-stop.out','r')
tfidffile = open('1-5yes-words-tfidf.out','r')

resultfile = open('1-9-tweet-rank.out','w')

num = 0
wordsTFIDF = { }
result = { }
originContent = { }

for l in originweibofile:
	num+=1
	line = l.split(',',3)
	if len(line) < 4:
		print num
		print l
		continue
	tid = line[0]
	uid = line[1]
	if len(line[2])<13:
		print num
		print l
		continue
	weibo_time = line[2][0:19]
	content = line[3]
	originContent[num]=l

num=0
for l in tfidffile:
	num+=1
	line = l.split(' ',1)
	word = line[0]
	tfidf = float(line[1])
	wordsTFIDF[word] = tfidf

num=0
for l in weibofile:
	num+=1
	words = l.split()
	wordCount = len(words)
	weiboScore = 0
	for w in words:
		weiboScore += wordsTFIDF.get(w,0)
	result[num] = weiboScore/wordCount

print "read ok"


outresult = [[v[1],v[0]] for v in result.items()]
outresult.sort(reverse=True)
for v in outresult:
	outline = originContent[v[1]].strip()
	outline = str(v[0])+","+outline+"\n"
	resultfile.write(outline)
print "sort ok"

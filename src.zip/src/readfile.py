#-*-coding:UTF-8
import math
'''
trfile = open("../data/HuoJianHuaTMA",'r')
qrfile = open("../data/HuoJianHuaQMA",'r')

wfile = open("../data/HuoJianHuaTQMA",'w')
TQMAdic={}

for k in trfile.readlines():
	ts  = k.split(',')
	TQMAdic[int(ts[0])]=[ts[1]]

for  s in qrfile.readlines():
	tq  = s.split(',')
	TQMAdic[int(tq[0])].append(str(tq[1]))
keylist  = TQMAdic.keys()
keylist.sort

for kk in keylist:
	wfile.write(str(kk).encode('utf8'))
	wfile.write(',')
	wfile.write(TQMAdic[kk][0])
	wfile.write(',')
	wfile.write(TQMAdic[kk][1])
	wfile.write('\n')
trfile.close()
qrfile.close()
wfile.close()
'''

rfile = open("../data/HuoJianHuaTQMA",'r')
wfile = open("../data/HuoJianHuaPartTQMA",'w')
dlist = []
templist=[]

for k in rfile.readlines():
	ts = k.rstrip('\n').split(',')
	templist=[float(ts[1]),float(ts[2])]
	dlist.append(templist)

dlist.sort(cmp=lambda x,y:cmp(x[1],y[1]),reverse=False)
for i in dlist:
	wfile.write(str(i[0]))
	wfile.write(',')
	wfile.write(str(i[1]))
	wfile.write('\n')






	


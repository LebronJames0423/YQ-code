import datetime
import time


"""
weibofile = open('weiboData-20140604.old','r')
resultfile = open('0604result.out','w')
weibofile = open('weiboData-20140504.old','r')
resultfile = open('0504result.out','w')
"""
weibofile = open('weiboData-20140704.old','r')
resultfile = open('0704result.out','w')

num = 0
result = { }
for l in weibofile:
	num+=1
	line = l.split(',',3)
	if len(line) < 4:
		print num
		print l
		continue
	tid = line[0]
	uid = line[1]
	if len(line[2])<13:
		print num
		print l
		continue
	time = line[2][0:13]
	content = line[3]
	if result.has_key(time):
		result[time].append(tid)
	else:
		result[time]=[tid]

print "read ok"

for k in sorted(result.keys()):
	outline = k+"\t"+str(len(result[k]))+"\n"
	resultfile.write(outline)
print "output ok"

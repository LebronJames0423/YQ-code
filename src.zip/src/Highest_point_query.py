#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
import time
import datetime
import math

config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic

dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2013-09-04 00:00:00','$lt':'2013-11-04 23:59:59'}})

number =dbresult.count()
print number


dbresult_s = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2014-04-26 00:00:00','$lt':'2014-07-03 23:59:59'}})
print dbresult_s.count()


sets = set()
highhourlydic = {}
topicFre={}
topicdic={}
timelist = []
countnumber =0
countnumbers =0
format = "%Y-%m-%d %H:%M:%S" 
#按照name进行聚合

for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			rname=name['name'].encode('utf8')
			if not topicdic.has_key(rname):
				topicdic[rname] = [[int(name['amount']),topic['crawl_time'].encode('utf8')]]
			else:
				topicdic[rname].append([int(name['amount']),topic['crawl_time'].encode('utf8')])


for topic in dbresult_s:
	for k,v in topic['trends'].items():
		for name in v:
			rname=name['name'].encode('utf8')
			if not topicdic.has_key(rname):
				topicdic[rname] = [[int(name['amount']),topic['crawl_time'].encode('utf8')]]
			else:
				topicdic[rname].append([int(name['amount']),topic['crawl_time'].encode('utf8')])




def Hourly_highest(Topicdic):
	Hourly_highdic = {}
	for k in Topicdic.keys():
		maxamount = 0
		maxtime = "0"
		for value in Topicdic[k]:
			if value[0]>maxamount:
				maxamount = value[0]
				maxtime = value[1]
		Hourly_highdic[k]=maxtime[:13]
	return Hourly_highdic


def Daily_highest(Topicdic):
	Daily_highdic = {}
	for k in Topicdic.keys():
		timedic={}
		for value in Topicdic[k]:
			if  value[1][:10] not in timedic.keys():
				timedic[value[1][:10]]=value[0]
			else:
				timedic[value[1][:10]]+=value[0]

		Topicdic[k]=timedic


	for kk in Topicdic.keys():
		maxamount = 0
		maxtime = "0"
		for v in Topicdic[kk].keys():
			print v
			if Topicdic[kk][v]> maxamount:
				maxamount = Topicdic[kk][v]
				maxtime = v
		Daily_highdic[kk] = maxtime 

	return Daily_highdic

def WriteFile(filename,resultdic):
	wfile  = open('../data/'+filename+".txt",'w')
	for name in resultdic.keys():
		wfile.write(name)
		wfile.write(',')
		wfile.write(resultdic[name])
		wfile.write('\n')
	wfile.close()

def main():
	hourlyres=Hourly_highest(topicdic)
	WriteFile('Q_hightime_hourlys',hourlyres)
	dailyres = Daily_highest(topicdic)
	WriteFile('Q_hightime_dailys',dailyres)
	


if __name__=='__main__':
	main()

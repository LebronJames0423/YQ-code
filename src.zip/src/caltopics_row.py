#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
#dbresult = hottopicdb.find().limit(number)
dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2014-04-25 00:00:00','$lt':'2014-04-25 23:59:59'}})

number =dbresult.count()
print number

sets = set()
topicdic = {
		}
timelist = []
countnumber =0
countnumbers =0

#按照name进行聚合
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			if not topicdic.has_key(name['name']):
				topicdic[name['name']] = [[name['amount'],topic['crawl_time']]]
			else:
				templist  = topicdic[name['name']]
				templist.append([name['amount'],topic['crawl_time']])
			#print set


#将内容写进文件里面
#name amount time,格式
outFile = open("../data/calwordtemp.txt","w")
for word in topicdic.keys():
	outFile.write(word.encode('utf8'))
	outFile.write("\n")
	for element in topicdic[word]:
		sep=','
		outFile.write(sep.join(element))
		outFile.write("\n")

	
outFile.close()



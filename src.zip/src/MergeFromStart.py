#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2013-09-05 00:00:00','$lt':'2013-11-09 23:59:59'}})

number =dbresult.count()
print number

#timesets = set()
querydic = {}
timelist = []
tweetdic = {}
finaldic = {}
timedic = {}
finallist = []
topicname  = "华晨宇" 
topicnames = "HCY_Hourly_Tweet_Count2013-09-05-60" 

#第一遍取得所有的时间
for topic in dbresult:
	timelist.append((topic['crawl_time'][:13]).encode('utf8'))


Qfile = open('./data20131202/'+topicname+".txt","r")
Tfile = open('./data20131202/'+topicnames+".txt","r")
outFile = open('./data20131202/'+topicname+"Merge.txt","w")

#topiclist = topicdic.items()
#topiclist.sort(cmp=lambda x,y:cmp(x[1][0],y[1][0]),reverse=True)
#把query中的数据导出,key is the time while value is the amount
Qfile.readline()
for lines in Qfile.readlines():
	line = lines.rstrip().split(',')
	querydic[line[0][:13]]=line[1]

#Now is exporting the Tweet data from file, the same with querydic
Tfile.readline()
for lines in Tfile.readlines():
	line = lines.rstrip().split(',')
	tweetdic[line[0][:13]]=line[1]

#Now exporting the final dic, marked as finaldic
for t in timelist:
	finaldic[t]=[0,0]

for t in finaldic.keys():
	if querydic.has_key(t): 
		finaldic[t]=[querydic[t]]
		if tweetdic.has_key(t):
			finaldic[t].append(tweetdic[t])
		elif not tweetdic.has_key(t):
			finaldic[t].append(0)
	elif not querydic.has_key(t):
		finaldic[t]=[0]
		if tweetdic.has_key(t):
			finaldic[t].append(tweetdic[t])
		elif not tweetdic.has_key(t):
			finaldic[t].append(0)

finallist = finaldic.items()
finallist.sort(cmp=lambda x,y:cmp(x[0],y[0]),reverse=False)

#Now write the finalresult to file
for word in finallist:
	outFile.write(word[0])
	for words in word[1]:
		outFile.write(',')
		outFile.write(str(words))
	outFile.write('\n')
outFile.close()
Qfile.close()
Tfile.close()



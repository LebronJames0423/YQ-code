#-*-coding:UTF-8
import math

Filename = "../data/HuoJianHuaTQ.txt"
Wfilename = "../data/HuoJianHuaQMA"

	
def GetData(Filename):
	Rfile = open(Filename,'r')
	Amountda={}
	count = 0
	for line in Rfile.readlines():
		ts = line.rstrip('\n').split(',')

		"""
		 ts[1] 为tweet中的数字，ts[2]为query的数量
		"""

		Amountda[count]= int(ts[2])
		count+=1
	Rfile.close()
	return Amountda

def MAerror(origin,new):
	erro = origin-new
	return erro

def SingleMovingAve(amountdata, window):
	num =0
	Movadic = {}
	while num <= (len(amountdata)-window):
		snum = 0
		result = 0
		while snum < window:
			result += amountdata[num+snum] 
			snum += 1
		Movadic[num]= [float(result)/int(window)]
		maerror = MAerror(amountdata[num+int(window)-1],Movadic[num][0])
		squaerror = maerror * maerror
		Movadic[num].append(maerror)
		Movadic[num].append(squaerror)
		num+=1
	return Movadic

def WriteFile(amountdic,filename):
	wfile = open(filename,"w") 
	for k in amountdic.keys():
		wfile.write(str(k).encode('utf8'))
		for value in amountdic[k]:
			wfile.write(",")
			wfile.write(str(value).encode('utf8'))
		wfile.write("\n")

	wfile.close()

'''计算平均平方差'''
def MeanSqErr(avedata):
	sum = 0
	for k in avedata.keys():
		sum += avedata[k][2] 
	mse = float(sum)/len(avedata)
	return mse

def main():

	AvergWin = 3
	Amountdata = GetData(Filename)
	print "file get finish"
	MovAveData = SingleMovingAve(Amountdata,AvergWin)
	print "file cal finish"
	WriteFile(MovAveData,Wfilename)
	print "file wirte finish"
	print MeanSqErr(MovAveData)



if __name__=="__main__":
	main()
		

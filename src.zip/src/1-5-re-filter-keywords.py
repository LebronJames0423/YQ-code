#-!-encoding:utf-8-!-
import datetime
import time

weibofile = open('1.out','r')
yesfile = open('1-5yes.out','w')
nofile = open('1-5no.out','w')

keywords = ["奶茶妹妹","刘强东","清华","京东"]
keyword = "章泽天"

num = 0
result = { }
for l in weibofile:
	num+=1
	line = l.split(',',3)
	if len(line) < 4:
		print num
		print l
		continue
	tid = line[0]
	uid = line[1]
	if len(line[2])<13:
		print num
		print l
		continue
	weibo_time = line[2][0:19]
	content = line[3]
	#t = time.strptime(weibo_time,"%Y-%m-%d %H:%M:%S")
	content = content.strip()
	#content = content.decode('utf8')
	outline = l
	if keyword in content:
		yesfile.write(outline)
		continue
	flag = False
	count = 0
	for word in keywords:
		if word in content:
			count += 1
		if 2==count:
			yesfile.write(outline)
			flag = True
			break

	if False == flag:
		nofile.write(outline)
print "read ok"

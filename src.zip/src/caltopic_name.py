#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
number =hottopicdb.count()
print number
#dbresult = hottopicdb.find().limit(number)
dbresult = hottopicdb.find({'trends_by':1
	})

sets = set()
dbresult_by2 = hottopicdb.find({
	'trends_by':2
	})

outFile = open("wordsbyhour.txt","w+")
outFile2 = open("wordsbyday.txt","w+")

#write the word by hour to the txt
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			sets.add(name['name'])
			#print name['name'],
for word in sets:
	outFile.write(word.encode('utf8'))
	outFile.write("\n")

#dbresult.rewind()

#write the words by day to the daytxt	
for topic in dbresult_by2:
	outFile2.write(topic['crawl_time'])
	outFile2.write("\n")
	for k,v in topic['trends'].items():
		for name in v:
			outFile2.write(name['name'].encode('utf8'))
			outFile2.write("   ")
	outFile2.write("\n")

"""
#将内容写进文件里面
outFile = open("calword.txt","w")
for word in sets:
	outFile.write(word.encode('utf8'))
	outFile.write("\n")
	for temp in dbresult:
		print "hello"
		outFile.write("hello")
		for kk,vv in temp['trends'].items():
			for names in vv:
				if names['name']== word:
					outFile.write(names['amount'])
					outFile.write(" ")
					outFile.write(temp['crawl_time'])
					outFile.write("\n")
				else:
					outFile.write("no words")

outFile.close()
"""
outFile.close()
outFile2.close()

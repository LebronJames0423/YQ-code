#-!-encoding:utf-8-!-
import datetime
import time
import math

weibofile = open('1.out','r')
wordsfile = open('1-5yes-words-count.out','r')

dffile = open('1-5yes-words-df.out','w')
idffile = open('1-5yes-words-idf.out','w')

dfall = 19646978


num = 0
result = { }
wordCount = 0
wordsAll = []

for l in wordsfile:
	num+=1
	l = l.strip()
	words = l.split(' ',1)
	if len(words)<2:
		print str(num)+":words len < 2"
	wordsAll.append(words[0])
print "read words ok"

num = 0
for l in weibofile:
	num+=1
	line = l.split(',',3)
	if len(line) < 4:
		print str(num)+":weibo len < 4"
		continue
	tid = line[0]
	uid = line[1]
	weibo_time = line[2][0:19]
	content = line[3]
	content = content.strip()
	for word in wordsAll:
		if word in content:
			result[word] = result.get(word,0)+1
print "read weibo ok"

for k,v in result.iteritems():
	outline = k+" "+str(v)+"\n"
	dffile.write(outline)
print "df ok"

for k,v in result.iteritems():
	idf = math.log(float(dfall)/v)
	outline = k+" "+str(idf)+"\n"
	idffile.write(outline)
print "idf ok"


#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy

config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
dbresult = hottopicdb.find().limit(1)
#dbresult = hottopicdb.find({'trends_by':1})
topicdic ={}
new_topicdic={}
dset = set()
n_worddic={}
total_worddic={}
for topic in dbresult:
	print topic

#按照name进行聚合
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			if not topicdic.has_key(name['name']):
				topicdic[name['name']] = [[name['amount'],topic['crawl_time']]]
			else:
				templist  = topicdic[name['name']]
				templist.append([name['amount'],topic['crawl_time']])
			#print set


#name amount time,格式
outFile = open("New_old_words_Ed.txt","w")


#统计每天出现的新词
for word in topicdic.keys():
	s  = topicdic[word]
	dt = s[0][1]
	if not n_worddic.has_key(dt[:10]):
		n_worddic[dt[:10]]=[word.encode('utf8')]
	else:
		tempt_list = n_worddic[dt[:10]]
		tempt_list.append(word.encode('utf8'))
keys = n_worddic.keys()
keys.sort()

#统计每天旧词
for word in topicdic.keys():
	s  = topicdic[word]
	for i in range(0,len(s)):
		dt = s[i][1]
		if not total_worddic.has_key(dt[:10]):
			total_worddic[dt[:10]]=[word.encode('utf8')]
		else:
			tempt_list = total_worddic[dt[:10]]
			if not word.encode('utf8')in tempt_list:
				tempt_list.append(word.encode('utf8'))
total_keys = total_worddic.keys()
total_keys.sort()


for w in total_keys:
	outFile.write(w)
	outFile.write("\n")
	outFile.write("OLD WORDS:  ")
	outFile.write(str(len(total_worddic[w])-len(n_worddic[w])))
	outFile.write("\n")
	old_wordlist=[val for val in total_worddic[w]if val not in n_worddic[w]]
	for t in old_wordlist:
		outFile.write(t)
		outFile.write(" ")
	outFile.write("\n")
	outFile.write("NEW WORDS: ")
	outFile.write(str(len(n_worddic[w])))
	outFile.write("\n")
	for m in n_worddic[w]:
		outFile.write(m)
		outFile.write(" ")
	outFile.write("\n")



outFile.close()


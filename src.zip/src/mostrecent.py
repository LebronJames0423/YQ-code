#coding=utf8
import math
import random

filename=''
writeFilename = ''
filecount=0
res_num = 3
tweet={}


def LoadFile():
	zyyfile = open("../data/"+filename,"r")
	for line in slice.readlines():
		ti = line.strip('\n').split(',',3)
		if not keydic.has_key(ti[2]:14):
			tweet[ti[2]:[14]]=[ti[3]]
		else:
			tweet[ti[2]:[14]].append(ti[3])
	zyyfile.close()

def WriteFile():
	zy = open("../data/"+writeFilename+".txt","w")
	keylist = keydic.items()
	keylist.sort(cmp=lambda x,y:cmp(x[0],y[0]),reverse)

	for jj in keylist:
		if num < res_num:
			zy.write(str(jj[keylist]).encode('utf8'))
			zy.write(';')
		num=num+1
		zy.write("\n")
	zy.close()

def main():
	LoadFile()
	WriteFile()

if __name__=="__main__":
	main()

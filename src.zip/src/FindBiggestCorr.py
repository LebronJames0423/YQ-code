import time
import urllib
#coding=utf8
import math
import Corr
import catopics1202


FinalCorrResultDic={}
topicdic = {}
keylist=[]

def FindBiggestCorr():
	topicdic = catopics1202.GetTopics()
	for keyone in topicdic.keys():
		if keyone not in keylist:
			keylist.append(keyone)
		for keytwo in topicdic.keys():
			if keytwo not in keylist:
				tempresult = Corr.Correlate(topicdic[keyone],topicdic[keytwo])
				print tempresult
				FinalCorrResultDic[keyone+' '+keytwo]=tempresult
	
	QueryFile = open("./2013-1212-1218/data/QueryRelation2013-10-12-19 threshold 10 and 2d.txt","w")	
	topiclist = FinalCorrResultDic.items()
	topiclist.sort(cmp=lambda x,y:cmp(x[1],y[1]),reverse=True)
	
	for word in topiclist:
		QueryFile.write(word[0])
		QueryFile.write(",")
		QueryFile.write(str(word[1]))
		QueryFile.write("\n")

	QueryFile.close()

FindBiggestCorr()


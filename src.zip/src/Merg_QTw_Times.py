#coding=utf8
import math

Amount = {}
AmountQ={}
keylist =[]

name = "../data/霍建华"
zyyfile = open(name+".txt",'r')
for line in zyyfile.readlines():
	ti = line.rstrip('\n').split(",")
	tmp  = ti[0].replace(":"," ")
	Amount[tmp[:13]]=ti[1].rstrip()

zyy = open("../data/HuoJianHua.txt","r")
zy = open("../data/HuoJianHuaTQ.txt","w") 

for lines in zyy.readlines():
	ts = lines.rstrip('\n').split("\t")
	AmountQ[ts[0]]=[ts[1]]


for i in AmountQ.keys():
	if Amount.has_key(i):
		AmountQ[i].append(Amount[i[:13]])
	else:
		AmountQ[i].append("0")

for j in AmountQ.keys():
	keylist.append(j)
keylist.sort()
for jj in keylist:
	zy.write(jj)
	for number in AmountQ[jj]:
		zy.write(",")
		zy.write(number)
	zy.write("\n")		

zyyfile.close()
zyy.close()
zy.close()


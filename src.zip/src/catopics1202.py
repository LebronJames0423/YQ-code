#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
import datetime
import math


def GetTopics(): 
	config = {
			'hottopicdb':{
				'host':'219.223.215.190','port':27017,
				'db':'weibo_TrendsV1','collection':'hottopic'
				}
			}

	con = pymongo.Connection('219.223.215.190',27017)
	trendsdb = con.weibo_TrendsV1
	hottopicdb = trendsdb.hottopic
	dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2013-09-04 00:00:00','$lt':'2013-11-04 23:59:59'}})


	threhold = 10
	templist = {}
	topicdica ={}
	number =dbresult.count()
	format = "%Y-%m-%d %H:%M:%S"

	sets = set()
	topicdic = {}
	timelist = []
	rec = []
	countnumber =0
	countnumbers =0
	topicd={}
	#第一遍
	for topic in dbresult:
		for k,v in topic['trends'].items():
			for name in v:
				if not topicdic.has_key(name['name'].encode('utf-8')):
					topicdic[name['name'].encode('utf-8')] = [[topic['crawl_time'],name['amount']]]
				else:
					topicdic[name['name'].encode('utf-8')].append([topic['crawl_time'],name['amount']])

		timelist.append(topic['crawl_time'])

	for t in topicdic.keys():
		highestvalue=0
		highestkey = 0
		for i in range(0,len(topicdic[t])):
			res = topicdic[t][i]
			if int(res[1])>highestvalue:
				if t=='华晨宇':
					print int(res[1])
				highestvalue=int(res[1])
				highestkey=i
		topicd[t]=topicdic[t][highestkey][0]

		'''
			
		if topicdic[t][0]>topicdic[t][1]>0:
			rec.append(timelist[0])
		for y in range(2,len(trec),1):
			if topicdic[t][trec[y-1]]>topicdic[t][trec[y-2]]and topicdic[t][trec[y-1]]>topicdic[t][trec[y]]:
				rec.append(timelist[y-1])
		topicd[t]=rec
		'''


		'''
		if tynumber >= threhold:
			startday = time.strptime(timelist[rec[0]],format)
			sday = datetime.datetime(startday[0],startday[1],startday[2],startday[3],startday[4],startday[5])
			ndays = time.strptime(timelist[rec[len(rec)-1]],format)
			nd = datetime.datetime(ndays[0],ndays[1],ndays[2],ndays[3],ndays[4],ndays[5])
			gaps=3600*24*int(str((nd-sday).days))+int(str((nd-sday).seconds))
			gg=gaps/(3600*24.0)
			ga=math.ceil(gg)
			if int(ga)>=2:
				if (topicdic[t][rec[0]]<= topicdic[t][rec[1]]) and (rec[tynumber-1]<=(number-3)):
					topicdica[t]=topicdic[t]
					topicd[t]=int(ga)
		'''

	'''

	outFiles = open("../data/TopicHighestTimeClass.txt",'w')

	topicdica['4']=[]
	topicdica['2-3']=[]
	topicdica['1']=[]
	for k in topicd.keys():
		if len(topicd[k])>=4:
			topicdica['4'].append(k)
		elif len(topicd[k])>=2 and len(topicd[k])<=3:
			topicdica['2-3'].append(k)
		elif len(topicd[k])<=1:
			topicdica['1'].append(k)
	outFiles.write("#")
	outFiles.write('times')
	outFiles.write('\n')
	for word in topicdica.keys():
		outFiles.write(word)
		outFiles.write(",")
		for i in topicdica[word]:
			outFiles.write(str(i))
			outFiles.write(',')
		outFiles.write("\n")
	outFiles.close()
	'''

	outFile = open("../data/TopicsTheHighestTime.txt",'w')
	outFile.write("#")
	outFile.write("topic")
	outFile.write(",")
	outFile.write('time')
	outFile.write('\n')
	for word in topicd.keys():
		outFile.write(word)
		outFile.write(",")
		outFile.write(topicd[word])
		'''
		for i in topicd[word]:
			outFile.write(str(i))
			outFile.write(',')
		'''
		outFile.write("\n")
		
	outFile.close()

'''
	for word in topicdica.keys():
		if word in namelist:
			outFile.write(",")
			outFile.write(word)
	outFile.write("\n")
	for n in range(1,number,1):
		#添加行号
		#outFile.write(str(n))
		#outFile.write(",")
		outFile.write(timelist[n-1])
		for word in topicdica.keys():
			if word in namelist:
				outFile.write(",")
				templist = topicdica[word]
				outFile.write(str(templist[n-1]))
		outFile.write("\n")
'''
	#outFile.close()
	#return topicdica

GetTopics()
	

	
"""
#name amount time,格式
outFile = open("calword.txt","w")
for word in topicdic.keys():
	outFile.write(word.encode('utf8'))
	outFile.write("\n")
	for element in topicdic[word]:
		sep=','
		outFile.write(sep.join(element))
		outFile.write("\n")

	
	for temp in finalresult:
		print "hello"
		outFile.write("hello")
		for kk,vv in temp['trends'].items():
			for names in vv:
				if names['name']== word:
					outFile.write(names['amount'])
					outFile.write(" ")
					outFile.write(temp['crawl_time'])
					outFile.write("\n")
				else:
					outFile.write("no words")
GetTopics()
"""

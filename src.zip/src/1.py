import datetime
import time


"""
startDate = datetime.datetime(2014,5,21,0,0,0)
endDate = datetime.datetime(2014,5,25,23,59,59)
"""
startDate = time.strptime("2014-05-21 00:00:00","%Y-%m-%d %H:%M:%S")
endDate = time.strptime("2014-05-25 23:59:59","%Y-%m-%d %H:%M:%S")
weibofile = open('weiboData-20140604.old','r')
resultfile = open('1.out','w')

num = 0
result = { }
for l in weibofile:
	num+=1
	line = l.split(',',3)
	if len(line) < 4:
		print num
		print l
		continue
	tid = line[0]
	uid = line[1]
	if len(line[2])<13:
		print num
		print l
		continue
	#weibo_time = line[2][0:13]
	weibo_time = line[2][0:19]
	content = line[3]
	t = time.strptime(weibo_time,"%Y-%m-%d %H:%M:%S")
	if(t>=startDate and t<=endDate):
		print t
		outline = l
		resultfile.write(outline)
print "read ok"

#coding=utf8
import math

Amount = {}
AmountQ={}
xmount={}
Tweamount={}
q={}
keylist =[]
it  =''
def Merge():
	zyyfile = open("result2.txt")

	for line in zyyfile.readlines():
		ti = line.rstrip().split(",")
		if(len(ti)<2):
			it = ti[0]
			Amount[it]={}
		else:
			tmpdic=Amount[it]
			ti[0]=ti[0].replace(':',' ')
			print ti[0]
			tmpdic[ti[0]]=int(ti[1])
			Amount[it]=tmpdic 
			

	print len(Amount)
	zyy = open("word_14-20.txt","r")
	zx = open("wordsnew-14-20.txt","r")
	zy = open("words1106-14-20.txt","w")

	for ll in zx.readlines():
		tx = ll.rstrip().split(",")
		if(len(tx)<2):
			xt = tx[0]
			xmount[xt]={}
		else:
			tmpdic=xmount[xt]
			tmpdic[tx[0][:13]]=int(tx[1])
			xmount[xt]=tmpdic 
	
	for l in Amount.keys():
		Tweamount[l]=0
		if xmount.has_key(l):
			for kn in Amount[l].keys():
				if xmount[l].has_key(kn):
					print "yes"+kn
					Tweamount[l]+=int(Amount[l][kn])
					print Amount[l][kn]


	zyy.readline()
	for lines in zyy.readlines():
		ts = lines.split(",")
		AmountQ[ts[0]]=[int(ts[1])]

	for i in AmountQ.keys():
		if Tweamount.has_key(i):
			AmountQ[i].append(Tweamount[i])
		else:
			AmountQ[i].append(0)
	mounts = AmountQ.items()
	mounts.sort(cmp=lambda x,y:cmp(x[1][0],y[1][0]),reverse=True)

	zy.write("topic")
	zy.write(",")
	zy.write("query")
	zy.write(",")
	zy.write("tweet")
	zy.write("\n")

	for jj in mounts:
		if jj[1][1]!=0:
			print mounts[2]
			zy.write(jj[0])
			for number in jj[1]:
				zy.write(",")
				zy.write(str(number))
			zy.write("\n")		

	zyyfile.close()
	zyy.close()
	zy.close()
	zx.close()

def Paixu(q):
	"""
	newfile = open("word-10-1.txt","r+")
	newfile.readline()
	for lines in newfile.readlines():
		ts=lines.split(",")
		q[ts[0]] = [int(ts[1])]
		q[ts[0]].append(int(ts[2]))
"""
	mount = q.items()
	mount.sort(cmp=lambda x,y:cmp(x[1][0],y[1][0]),reverse=True)
	return mount
"""
	for jj in mount:
		if jj[1][1]!=0:
			newfile.write(jj[0])
			for number in jj[1]:
				newfile.write(",")
				newfile.write(str(number))
			newfile.write("\n")		
	newfile.close()
	"""
def Tweedata():
	file = open("Words-14-20.txt","r")
	newfile = open("words1106-14-20.txt","r")
	topicdic ={}
	for lines in file.readlines():
		ts = lines.split(",")
		topicdic[ts[0]]=[int(ts[2])]
	
	newfile.readline()
	for lines in newfile.readlines():
		ts = lines.split(",")
		if topicdic.has_key(ts[0]):
			topicdic[ts[0]].append(int(ts[2]))
	mounts =Paixu(topicdic) 

	comptdatafile  = open("Comptwe_data14-20.txt","w")
	comptdatafile.write("topic")
	comptdatafile.write(",")
	comptdatafile.write("Old_Amount")
	comptdatafile.write(",")
	comptdatafile.write("New_Amount")
	comptdatafile.write("\n")

	for topics in mounts:
		comptdatafile.write(topics[0])
		for number in topics[1]:
			comptdatafile.write(",")
			comptdatafile.write(str(number))
		comptdatafile.write("\n")

	file.close()
	newfile.close()
	comptdatafile.close()

#Paixu()
#Merge()
Tweedata()


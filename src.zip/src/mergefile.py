#coding=utf8
import math

Amount = {}
AmountQ = 0
keydic={}
newnamelist = []
filename='Topic_Hours.txt'
#filename = 'Topic_Days.txt'
writeFilename = 'EmergingHours.txt'

def LoadFile():
	zyyfile = open("../data/"+filename,"r")
	for line in zyyfile.readlines():
		ti = line.strip('\n').split(',')
		if not keydic.has_key(int(ti[2])):
			keydic[int(ti[2])]=[ti[1]]
		else:
			keydic[int(ti[2])].append(ti[1])

	zyyfile.close()

def WriteFile():
	zy = open("../data/"+writeFilename+".txt","w")
	n=1
	keylist = keydic.items()
	keylist.sort(cmp=lambda x,y:cmp(x[0],y[0]),reverse=False)
	for jj in keylist:
		zy.write(str(jj[0]).encode('utf8'))
		zy.write(',')
		zy.write(str(len(jj[1])))
		zy.write("\n")
	zy.close()

def main():
	LoadFile()
	WriteFile()

if __name__=="__main__":
	main()

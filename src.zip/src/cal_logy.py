#coding=utf8
import math

Amount = {}
AmountQ={}
keylist =[]

zyy = open("./data20131202/华晨宇Merge.txt")
"""
for line in zyyfile.readlines():
	ti = line.split(",")
	tmp  = ti[0].replace(":"," ")
	Amount[tmp]=ti[1].rstrip()
"""
zy = open("./data20131202/HCYMergelog.txt","w+")
#zyy.readline()
for lines in zyy.readlines():
	ts = lines.rstrip().split(",")
	var =int(ts[1])
	vars =int(ts[2])

	if var>0:
		AmountQ[ts[0]]=[round(math.log(var),2)]
	else:
		AmountQ[ts[0]]=[var]
	if vars>0:
		AmountQ[ts[0]].append(round(math.log(vars),2))
	else:
		AmountQ[ts[0]].append(vars)

keylist = AmountQ.items()
keylist.sort(cmp=lambda x,y:cmp(x[0],y[0]),reverse=False)

for jj in keylist:
	zy.write(jj[0])
	for number in jj[1]:
		zy.write(",")
		zy.write(str(number))
	zy.write("\n")		

zyy.close()
zy.close()


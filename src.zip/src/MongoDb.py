#-!-encoding:utf-8-!-
import pymongo



class MongoDbConnectFailed(Exception):
	pass

class MongoDb(object):

	def __init__(self,conf):
		self.conf = conf
		try:
			self.connection = pymongo.Connection(self.conf['host'],self.conf['port'])
		except Exception,e:
			raise MongoDbConnectFailed('make Connection failed!')

		try:
			self.db = self.connection[self.conf['db']]
		except Exception,e:
			raise RuntimeError('use db failed![db:%s]'%(self.conf['db']))
		try:
			self.collection = self.db[self.conf['collection']]
		except Exception,e:
			raise RuntimeError('use collection failed![db:%s][collection:%s]'%(self.conf['db'],self.conf['collection']))
	def save(self,obj,primary_key=False):
		if primary_key != False:
			obj['_id'] = primary_key
		self.collection.save(obj)

	def loadItemsByCondition(self,condition,limitNum):
		return self.collection.find(condition).limit(limitNum)

	def loadDataToPool(self,limitNum,condition):
		return self.loadItemsByCondition(condition,limitNum)

	def updateDataStauteToWait(self,item,updateField):
		self.updateItemById(item,updateField)


	def updateItemById(self,item,updateField):
		condition = { "_id": item['_id'], }
		try:
			self.collection.update(condition,updateField,False,False) 
		except Exception,e:
			raise
		 



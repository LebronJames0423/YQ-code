#coding=utf8
#import matplotlib.pyplot as plot
import math
#import numpy as np

#date, query, timeline = [], [], []

def Correlate(x, y):
	n = len(x)
	avgx = sum(x) / n
	avgy = sum(y) / n
	cov = sum([(x[i] - avgx) * (y[i] - avgy) for i in range(n)])
	varx = sum([(x[i] - avgx) * (x[i] - avgx) for i in range(n)])
	vary = sum([(y[i] - avgy) * (y[i] - avgy) for i in range(n)])
	correlate = math.fabs((cov / math.sqrt(varx * vary)))
	return correlate

'''
h2file = open("TianTu.txt")
#h2file.readline()
for line in h2file.readlines():
	fields = line.rstrip().split(",")
	date.append(fields[0].split()[1])
	query.append(int(fields[1]))
	timeline.append(int(fields[2]))

corr = Correlate(query, timeline)
print corr
'''

#-*-coding:UTF-8
import pymongo

conn = pymongo.Connection('219.223.215.190',27017)
timelinedb = conn.bigweibo
timeline = timelinedb.bigweibo_celery
result= timeline.find().limit(1)

for items in result:
	print items

#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
#dbresult = hottopicdb.find().limit(number)
dbresult = hottopicdb.find({'trends_by':1,'crawl_time':{'$gt':'2013-09-04 00:00:00','$lt':'2013-11-04 23:59:59'}})
topicdic ={}
new_topicdic={}
totalwords = set()
dset = set()
n_worddic={}
nh_worddic={}
total_worddic={}

#按照name进行聚合
for topic in dbresult:
	for k,v in topic['trends'].items():
		for name in v:
			if not topicdic.has_key(name['name']):
				topicdic[name['name']] = [[name['amount'],topic['crawl_time']]]
			else:
				templist  = topicdic[name['name']]
				templist.append([name['amount'],topic['crawl_time']])
			#print set
print len(topicdic)

#name amount time,格式
outFile = open("../data/new_old_accumulated_words_day.txt","w")

#outFileh = open("../data/new_accumulated_words_hourly.txt","w")

#统计所有的词,n_worddic 按照天来统计，nh_worddic 为按照小时来统计
for word in topicdic.keys():
	s  = topicdic[word]
	dt = s[0][1]
	if not n_worddic.has_key(dt[:10].encode('utf8')):
		n_worddic[dt[:10].encode('utf8')]=[word.encode('utf8')]
	else:
		tempt_list = n_worddic[dt[:10].encode('utf8')]
		tempt_list.append(word.encode('utf8'))
keys = n_worddic.keys()
keys.sort()

print len(keys)
#统计每天旧词的数量
for word in topicdic.keys():
	s  = topicdic[word]
	for i in range(0,len(s)):
		dt = s[i][1]
		if not total_worddic.has_key(dt[:10].encode('utf8')):
			total_worddic[dt[:10].encode('utf8')]=[word.encode('utf8')]
		else:
			tempt_list = total_worddic[dt[:10].encode('utf8')]
			if not word.encode('utf8')in tempt_list:
				tempt_list.append(word.encode('utf8'))
total_keys = total_worddic.keys()
total_keys.sort()
print len(total_keys)

outFile.write("$time")
outFile.write(",")
outFile.write("old_words_everyday")
outFile.write(",")
outFile.write("new_words")
outFile.write(",")
outFile.write("old_words_total")
outFile.write(",")
outFile.write("acculated_new_words")
outFile.write("\n")

#将文件写入no_topictime.txt 文件中
for w in total_keys:
	outFile.write(w)
	outFile.write(",")
	if n_worddic.has_key(w):
		outFile.write(str(len(total_worddic[w])-len(n_worddic[w])))
	else:
		outFile.write(str(len(total_worddic[w])))
	for item in total_worddic[w]:
		totalwords.add(item)
	outFile.write(",")
	if n_worddic.has_key(w):
		outFile.write(str(len(n_worddic[w])))
	else:
		outFile.write(str(0))
	outFile.write(",")
	if n_worddic.has_key(w):
		outFile.write(str(len(totalwords)-len(n_worddic[w])))
	else:
		outFile.write(str(len(totalwords)))
	outFile.write(",")
	outFile.write(str(len(totalwords)))
	outFile.write("\n")
'''
for word in topicdic.keys():
	outFile.write(word.encode('utf8'))
	outFile.write("\n")
	for element in topicdic[word]:
		sep=','
		outFile.write(sep.join(element))
		outFile.write("\n")

'''
#calculate the times a word appear
'''
for word in topicdic.keys():
	outFile.write(word.encode('utf8'))
	outFile.write(' ')
	dset  = set()
	for element in topicdic[word]:
		t = time.strptime(element[1],'%Y-%m-%d %H:%M:%S')
		dset.add(t[2])
	outFile.write(str(len(dset)))
	outFile.write("\n")

'''
'''
for wo in topicdic.keys():
	s  = topicdic[wo]
	dt = s[0][1]
	print dt[:13]
	if not nh_worddic.has_key(dt[:13]):
		nh_worddic[dt[:13]]=[wo.encode('utf8')]
	else:
		templlist = nh_worddic[dt[:13]]
		templlist.append(wo.encode('utf8'))
keyss= nh_worddic.keys()
keyss.sort()
print len(nh_worddic)
print len(keyss)

outFileh.write("time")
outFileh.write(",")
outFileh.write("amount")
outFileh.write(",")
outFileh.write("accumulated amount")
outFileh.write("\n")
for w in keyss:
	outFileh.write(w)
	outFileh.write(",")
	for i in nh_worddic[w]:
		totalwords.add(i)
	outFileh.write(str(len(nh_worddic[w])))
	outFileh.write(",")
	outFileh.write(str(len(totalwords)))
	outFileh.write("\n")
#outFile.close()
'''
outFile.close()

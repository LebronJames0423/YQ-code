#!/usr/bin/python
#-*-coding:UTF-8
import time
import urllib
import httplib
import pymongo
import copy
config = {
		'hottopicdb':{
			'host':'219.223.215.190','port':27017,
			'db':'weibo_TrendsV1','collection':'hottopic'
			}
		}

con = pymongo.Connection('219.223.215.190',27017)
trendsdb = con.weibo_TrendsV1
hottopicdb = trendsdb.hottopic
dbresult = hottopicdb.find()

number =dbresult.count()
print number

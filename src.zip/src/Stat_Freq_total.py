#coding=utf8
import math
import Topic_eme_times

Amount = {}
AmountQ = 0
keylist =[]
categ =3 
if categ==1 :
	Topic_eme_times.EmergingTimes(1)
	zyyfile = open("../data/Topic_Days.txt","r")
elif categ==2:
	Topic_eme_times.EmergingTimes(2)
	zyyfile = open("../data/Topic_NatureDays.txt","r")
elif categ==3:
	Topic_eme_times.EmergingTimes(3)
	zyyfile = open("../data/Topic_Hours.txt","r")
elif categ==4:
	zyyfile = open("../data/TweetNumberHourly.txt","r")
elif categ==5:
	zyyfile = open("../data/TweetNumberDaily.txt","r")
elif categ==6:
	zyyfile = open("../data/TweetAvgNumberHourly.txt","r")
elif categ==7:
	zyyfile = open("../data/TweetAvgNumberDaily.txt","r")
'''
zyyfile.readline()
for ti in zyyfile.readlines():
	ti = ti.strip("\n").split(",")
	if not Amount.has_key(ti[0]):
		Amount[ti[0]]=[float(ti[1])]
	AmountQ+=1
'''


zyyfile.readline()
for line in zyyfile.readlines():
	ti = line.strip('\n').split(",")
	if not Amount.has_key(int(ti[2])):
		Amount[int(ti[2])]=[ti[1]]
		print ti[2]
	else:
		Amount[int(ti[2])].append(ti[1])
	AmountQ+=1



if categ==1 :
	zy= open("../data/EmergingDays.txt","w")
elif categ==2:
	zy = open("../data/EmergingNatureDays.txt","w")
elif categ==3:
	zy = open("../data/EmergingHours.txt","w")
elif categ==4:
	zy=open("../data/EmergingHoursTweet.txt","w")
elif categ==5:
	zy=open("../data/EmergingDaysTweet.txt","w")
elif categ==6:
	zy=open("../data/EmergingAvgHoursTweet.txt","w")
elif categ==7:
	zy=open("../data/EmergingAvgDaysTweet.txt","w")

#keylist = Amount.keys()
#keylist.sort(reverse = True)
keylist = Amount.items()
keylist.sort(cmp=lambda x,y:cmp(x[0],y[0]),reverse=False)
zy.write("$rank")
zy.write(",")
zy.write("Times")
zy.write(",")
zy.write("Number of Tweet")
zy.write("\n")
rank=1
t = 0
for jj in keylist:
	zy.write(str(rank))
	'''
	zy.write(",")
	zy.write(str(jj[0]))
	zy.write(",")
	zy.write(str(jj[1][0]))
	'''
	zy.write(",")
	zy.write(str(jj[0]))
	print jj[0]
	zy.write(',')
	zy.write(str(len(jj[1])))
	print len(jj[1])
	t+=len(jj[1])
	zy.write("\n")		
	rank+=1
print len(Amount)
print t
zyyfile.close()
zy.close()


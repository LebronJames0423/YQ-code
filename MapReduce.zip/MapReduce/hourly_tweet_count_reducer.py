#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import sys
from collections import defaultdict
infile  = sys.stdin

def formatDatetime(datetime):
	tempData = datetime.split('T')
	date = tempData[0]
	tempTime = tempData[1].split('+')
	hour = tempTime[0][0:2]
	return date+" "+hour

def Output(key, value):
	if key!= None:
		print key
		topiccountlist=value.items()
		topiccountlist.sort(cmp=lambda x,y:cmp(x[0],y[0]),reverse=False)
		for t in topiccountlist:
			count = str(t[1])
			print "{0}\t{1}".format(t[0],t[1])

def Output_tid(key, value):
	if key!= None:
		print key
		for t in value:
			outline = t+" "
			for item in value[t]:
				outline += item+" "
			outline = outline.rstrip()
			print outline

def TopicsCountReducer(infile):
	counttopic = None
	currenttime = None
	number=0
	#value = defaultdict(int)
	value = { }

	for line in infile:
		l = line.strip().split('\t')
		key = l[0]
		time = l[2]
		tid = l[1]

		if key == counttopic:
			#value[time]+=1
			value[formatDatetime(time)]+=1

			"""
			datetimeKey = formatDatetime(time)

			if datetimeKey in value:
				value[datetimeKey].append(tid)
			else:
				value[datetimeKey] = []
				value[datetimeKey].append(tid)
			"""
		else:
			Output(counttopic,value)
			#Output_tid(counttopic,value)
			counttopic = key
			#value = { }
			value = defaultdict(int)
			#value[time]+=1
			value[formatDatetime(time)]+=1
			#value[formatDatetime(time)] = [tid]
	Output(counttopic,value)
	#Output_tid(counttopic,value)

def main():
	TopicsCountReducer(infile)

if __name__=="__main__":
	main()


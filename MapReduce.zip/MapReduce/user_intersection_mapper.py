#!/usr/bin/env python
#-*- coding: utf-8 -*-
import sys
infile  = sys.stdin

def TopicCountMapper(infile):
	for l in infile:
		line = l.split(' ',4)
		uid = line[0]
		time = line[2]
		tid = line[3]
		content = line[4]
		topics = ['张翰 郑爽','许晴','文章 马伊琍','郑爽','汤唯','张一山','唐嫣','北京路','爱上两个我','华丽上班族']
		
		for each_topic in topics:
			if all([word in content for word in each_topic.split()]):
				print '{key}\t{value}'.format(key=uid,value=tid)

def main():
	TopicCountMapper(infile)


if __name__ == "__main__":
	main()

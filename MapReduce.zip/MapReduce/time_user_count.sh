#!/bin/bash
echo "Local version"

TIME_LOCAL_OUTPUT="time.user_count_local.txt"
for file; do
	echo -n "`wc -l $file` " >> $TIME_LOCAL_OUTPUT
	/usr/bin/time -f "%e" -a -o $TIME_LOCAL_OUTPUT \
		cat $file | user_count_local.py > "user.count.local.$file"
done

echo "Hadoop version"

TIME_HADOOP_OUTPUT="time.user_count_hadoop.txt"
for file; do
	echo -n "`wc -l $file` " >> $TIME_HADOOP_OUTPUT
	/usr/bin/time -f "%e" -a -o $TIME_HADOOP_OUTPUT \
		user_count_run.sh $file
done

#!/usr/bin/env python
#-*- coding: utf-8 -*-
import sys
infile  = sys.stdin

def TweetCountMapper(infile):
	for l in infile:
		line = l.split(' ',4)
		uid = line[0]
		time = line[2]
		tid = line[3]
		content = line[4]
		topics = ['张翰 郑爽','我觉得我室友喜欢我','郑爽','xbox','穆熙妍','郭美美','印尼版来自星星的你','18万骏马被车撞死','花样爷爷','奇皇后']
		
		for each_topic in topics:
			if all([word in content for word in each_topic.split()]):
				print '{key}\t{value}'.format(key=1,value=tid)

def main():
	TweetCountMapper(infile)


if __name__ == "__main__":
	main()

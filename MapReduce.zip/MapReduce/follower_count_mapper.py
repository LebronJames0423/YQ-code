#!/usr/bin/env python
import sys
infile  = sys.stdin

def TopicCountMapper(infile):
	for l in infile:
		line = l.split(' ')
		uid = line[0]
		time = line[2]
		tid = line[3]
		content = line[4]
		topics = ['李小璐','neinei','爸爸回来了','贾乃亮','大S','爸爸去哪儿第二季','吴奇隆','吴孟达','汪小菲','8个身份证']
		
		for topic in topics:
			if topic in topics:
				print '{key}\t{value}'.format(key=topic,value=tid)

def main():
	TopicCountMapper(infile)


if __name__ == "__main__":
	main()

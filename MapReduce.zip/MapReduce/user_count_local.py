#!/usr/bin/env python
"""
Count users of weibo in local.

Input:
    weibo_id uid weibo_text
    ...

Output:
    weibo_id count
    ...
"""
import sys


def main():
    uid_count = {}
    for line in sys.stdin:
        data = line.split()
        try:
            uid = int(data[1])
        except ValueError:
            # Broken input line.
            pass
        else:
            try:
                uid_count[uid] += 1
            except KeyError:
                uid_count[uid] = 1
    for uid, count in uid_count.iteritems():
        print uid, count


if __name__ == "__main__":
    main()

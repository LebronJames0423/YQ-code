#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import sys
infile  = sys.stdin

def Output(key, value):
	if key!= None:
		print '{key}\t{value}'.format(key=key,value=value)

def TweetCountReducer(infile):
	counttopic = None
	number=0
	values = []
	for line in infile:
		l = line.split('\t')
		value = l[1]
		if value not in values:
			values.append(l[1])

	Output('tweetsnumber',str(len(values)))

def main():
	TweetCountReducer(infile)

if __name__=="__main__":
	main()


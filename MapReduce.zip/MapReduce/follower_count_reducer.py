#!/usr/bin/env python
import sys
infile  = sys.stdin

def Output(key, value):
	if key!= None:
		print '{key}\t{value}'.format(key=key,value=value)

def FollowerCountReducer(infile):
	countnumber = 0
	countkey = None
	for line in infile:
		l = line.split()
		key = l[0]
		value = int(l[1])

		if key == countkey:
			countnumber = countnumber+value
		else:
			Output(countkey,countnumber)
			countkey = key
			countnumber = value
	Output(countkey,countnumber)

def main():
	FollowerCountReducer(infile)

if __name__=="__main__":
	main()


#!/usr/bin/env python
#-*- coding: utf-8 -*-
import sys
infile  = sys.stdin

def TweetCountMapper(infile):
	for l in infile:
		line = l.split(',',3)
		tid = line[0]
		uid = line[1]
		time = line[2][:14]
		content = line[3]

		print '{key}\t{value}'.format(key=time,value=tid)

def main():
	TweetCountMapper(infile)


if __name__ == "__main__":
	main()

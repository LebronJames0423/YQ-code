#!/usr/bin/env python
"""
User count reducer.

Input:
    uid count
    ...

Output:
    uid merged_count
    ...
"""
import sys


def main():
    current_uid = None
    current_count = 0
    for line in sys.stdin:
        data = line.split('\t')
        uid = int(data[0])
        count = int(data[1])
        if uid == current_uid:
            current_count += count
        else:
            if current_uid:
                print current_uid, current_count
            current_uid = uid
            current_count = count
    if current_uid:
        print current_uid, current_count


if __name__ == "__main__":
    main()

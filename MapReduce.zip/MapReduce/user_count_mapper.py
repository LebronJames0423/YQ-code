#!/usr/bin/env python
"""
User count mapper.

Input:
    weibo_id uid weibo_text
    ...

Output:
    uid\t1
    ...
"""
import sys


def main():
    for line in sys.stdin:
        data = line.split()
        try:
            uid = int(data[1])
        except (ValueError, IndexError):
            # Borken input line.
            pass
        print "{key}\t{value}".format(key=uid, value=1)


if __name__ == "__main__":
    main()

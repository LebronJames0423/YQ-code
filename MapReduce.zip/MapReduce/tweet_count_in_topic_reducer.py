#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import sys
infile  = sys.stdin

def Output(key, value):
	if key!= None:
		print '{key}\t{value}'.format(key=key,value=value)

def TopicsCountReducer(infile):
	counttopic = None
	number=0
	value = []
	for line in infile:
		l = line.split('\t')
		key = l[0]

		if key == counttopic and l[1] not in value:
			value.append(l[1])
		else:
			Output(counttopic,str(len(value)))
			counttopic = key
			value = []
			value.append(l[1])
	Output(counttopic,str(len(value)))

def main():
	TopicsCountReducer(infile)

if __name__=="__main__":
	main()


#!/usr/bin/env python
import logging
import sys


def main():
    logging.basicConfig(stream=sys.stderr, level=logging.WARNING)
    follower_count_table = {}
    for line in sys.stdin:
        data = line.split()
        try:
            uid = int(data[0])
            follower_id = int(data[1])
        except (IndexError, ValueError):
            logging.warning("Invalid input line:{0}".format(line.strip()))
        else:
            try:
                follower_count_table[uid] += 1
            except KeyError:
                follower_count_table[uid] = 1
    for uid, follower_count in follower_count_table.iteritems():
        print uid, follower_count


if __name__ == "__main__":
    main()

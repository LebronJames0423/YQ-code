#!/usr/bin/env python
#-*- coding: utf-8 -*-
import sys
infile  = sys.stdin

def TopicCountMapper(infile):
	for l in infile:
		line = l.split(' ')
		uid = line[0]
		time = line[2]
		tid = line[3]
		content = line[4]
		topics = ['张翰 郑爽','我觉得我室友喜欢我','郑爽','xbox','穆熙妍','郭美美','印尼版来自星星的你','18万骏马被车撞死','花样爷爷','奇皇后','汤唯']
		
		for topic in topics:
			if not (topic=="张翰 郑爽"):
				if topic in content:
					print '{key}\t{value}'.format(key=topic,value=tid)
			if topic == '张翰 郑爽':
				a='张翰'
				b = '郑爽'
				if a in content:
					if b in content:
						print '{key}\t{value}'.format(key=topic,value=tid)

def main():
	TopicCountMapper(infile)


if __name__ == "__main__":
	main()

#!/bin/bash

FILE_NAME=$1
LOCAL_FILE=$FILE_NAME

echo "Copy file to hadoop file system"
if [ -z "$HADOOP_INPUT" ]; then
    HADOOP_INPUT="/home/bigweibo/$FILE_NAME"
fi

/home/hadoop/hadoop-1.2.1/bin/hadoop fs -copyFromLocal $LOCAL_FILE $HADOOP_INPUT


echo "Run user count on hadoop"

if [ -z "$MAPPER" ]; then
    MAPPER="tweet_distribution_mapper.py"
fi

if [ -z "$REDUCER" ]; then
    REDUCER="tweet_distribution_reducer.py"
fi

if [ -z "$STREAMING_BIN_DIR" ]; then
    STREAMING_BIN_DIR="/home/hadoop/Projects/bigweibo/scripts"
fi

if [ -z "$OUTPUT" ]; then
    OUTPUT="tweet_distribution.$FILE_NAME"
fi

if [ -z "$HADOOP_OUTPUT" ]; then
    HADOOP_OUTPUT="/home/bigweibo/$OUTPUT"
fi

if [ -z "$HADOOP_CONFIG_PARAMETERS" ]; then
    HADOOP_CONFIG_PARAMETERS="-D mapred.reduce.tasks=25"
fi

echo "Remove output on hadoop"
/home/hadoop/hadoop-1.2.1/bin/hadoop fs -rmr $HADOOP_OUTPUT

/home/hadoop/hadoop-1.2.1/bin/hadoop jar /home/hadoop/hadoop-1.2.1/contrib/streaming/hadoop-streaming-1.2.1.jar $HADOOP_CONFIG_PARAMETERS -file $STREAMING_BIN_DIR/$MAPPER -mapper $MAPPER $WORD_LIST -file $STREAMING_BIN_DIR/$REDUCER -reducer $REDUCER -input $HADOOP_INPUT -output $HADOOP_OUTPUT

# echo "Get merged results"
# /home/hadoop/hadoop-1.2.1/bin/hadoop fs -getmerge $HADOOP_OUTPUT $OUTPUT
# 

#!/bin/bash
echo "Local version"

TIME_LOCAL_OUTPUT="time.follower_count_local.txt"
for file; do
	echo $file
	echo -n "`wc -l $file` " >> $TIME_LOCAL_OUTPUT
	/usr/bin/time -f "%e" -a -o $TIME_LOCAL_OUTPUT \
		cat $file | follower_count_local > "follower.count.local.$file"
done

echo "Hadoop version"

TIME_HADOOP_OUTPUT="time.follower_count_hadoop.txt"
for file; do
	echo $file
	echo -n "`wc -l $file` " >> $TIME_HADOOP_OUTPUT
	/usr/bin/time -f "%e" -a -o $TIME_HADOOP_OUTPUT \
		follower_count_run.sh $file
done

#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import sys
infile  = sys.stdin

def Output(key, value):
	if key!= None:
		print '{key}\t{value}'.format(key=key,value=value)

def TweetCountReducer(infile):
	counttopic = None
	number=0
	values = {}
	currenttime=None
	for line in infile:
		l = line.split('\t')
		value = l[1]
		k_time = l[0]

		if k_time == currenttime:
			values[k_time].append(value)
		else:
			if values.has_key(currenttime):
				Output(currenttime,str(len(values[currenttime])))
			currenttime = k_time
			values[k_time]=[value]

	Output(currenttime,str(len(values[currenttime])))

def main():
	TweetCountReducer(infile)

if __name__=="__main__":
	main()


#!/bin/bash
for i; do
	hourly_tweet_count_run.sh $i word_list.txt
done

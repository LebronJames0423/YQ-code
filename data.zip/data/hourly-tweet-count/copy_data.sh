#!/bin/bash
scp word_list.txt hadoop@hdmaster:~/data
scp word_list.txt hadoop@hdslave01:~/data
scp word_list.txt hadoop@hdslave02:~/data
scp word_list.txt hadoop@hdslave03:~/data
scp word_list.txt hadoop@hdslave04:~/data

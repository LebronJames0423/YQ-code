#!/usr/bin/env python
"""
Calculate:
    1. The number of hours in which we see tweets containing this hot topic.
    2. The average number of tweets per hour.
    3. The days in which we see tweets containing topic.
    4. The average number of tweets per day.
"""
import argparse
import sys


def parse_arguments():
    """
    Parse the command line arguments.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+", help="The input files.")
    return parser.parse_args()


def number_of_hours(data):
    """
    Calculate the number of hours in which we see tweets containing topic.

    @param data: The data of topics.
    """
    for word in data:
        print word,
        hours = 0
        for day in data[word]:
            hours += len(day)
        print hours


def average_number_of_tweets(data):
    """
    Calculate the average number of tweets per hour.

    @param data: The data of topics.
    """
    for word in data:
        print word,
        total = 0
        hours = 0
        for day in data[word]:
            for hour in day:
                total += day[hour]
                hours += 1
        print float(total)/hours


def number_of_days(data):
    """
    Calculate the days in which we see tweets containing topic.

    @param data: The data of topics.
    """
    for word in data:
        print word,
        print len(data[word])


def average_number_of_tweets_per_day(data):
    """
    Calculate the average number of tweets per day.

    @param data: The data of topics.
    """
    for word in data:
        print word,
        total = 0
        days = 0
        for day in data[word]:
            days += 1
            for hour in day:
                total += day[hour]
        print float(total)/days


def main():
    arguments = parse_arguments()
    data = {}
    for file_name in arguments.files:
        with open(file_name, 'r') as f:
            while True:
                try:
                    word = f.next().strip()
                except StopIteration:
                    break
                else:
                    hour_count = int(f.next())
                    dayily_data = {}
                    for i in range(hour_count):
                        line_data = f.next().split(',')
                        dayily_data[line_data[0]] = int(line_data[1])
                try:
                    data[word].append(dayily_data)
                except KeyError:
                    data[word] = [dayily_data]
    original_stdout = sys.stdout
    with open("number_of_hours.txt", "w") as f:
        sys.stdout = f
        number_of_hours(data)
        sys.stdout = original_stdout

    with open("number_of_days.txt", "w") as f:
        sys.stdout = f
        number_of_days(data)
        sys.stdout = original_stdout

    with open("average_number_of_tweets_per_hour.txt", "w") as f:
        sys.stdout = f
        average_number_of_tweets(data)
        sys.stdout = original_stdout

    with open("average_number_of_tweets_per_day.txt", "w") as f:
        sys.stdout = f
        average_number_of_tweets_per_day(data)
        sys.stdout = original_stdout


if __name__ == "__main__":
    main()
